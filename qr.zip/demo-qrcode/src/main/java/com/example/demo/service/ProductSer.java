package com.example.demo.service;

import com.example.demo.entities.Product;

public interface ProductSer {

	public Iterable<Product> findAll();
}
